import requests
import pandas as pd
from bs4 import BeautifulSoup

csvPath = r"./combined.csv"
csv = pd.read_csv(csvPath)
teachId = pd.read_csv(csvPath).tid

with open(r"C:/Users/Zack/Desktop/tags2.csv", "w") as f:
    count = 0
    for id in teachId:
        url = 'https://www.ratemyprofessors.com/ShowRatings.jsp?tid=' + str(id)

        r = requests.get(url)
        soup = BeautifulSoup(r.content, 'html.parser')

        tags = soup.select('span.tag-box-choosetags')
        tagList = []
        freq = []
        i=0;
        for tag in tags:
            tagList.append(tag.contents[0].replace("'", ""))
        #print(len(tagList))
        tagList = str(tagList).replace("'","")
        f.write(str(id))
        f.write(",  ")
        tagList = str(tagList).strip("[]")
        print(len(tagList))
        if (len(tagList) == 0):
            print(str(tagList))
            f.write("0")
        else:
            f.write(tagList)
        f.write("\n")
        #print(str(tagList).strip("[]"))











#Get individual teacher ids
# teachId = '318422'
# url = 'https://www.ratemyprofessors.com/ShowRatings.jsp?tid=' + teachId
#
# r = requests.get(url)
# soup = BeautifulSoup(r.content, 'html.parser')
#
# tags = soup.select('span.tag-box-choosetags')
# tagList = []
# freq = []
# with open(r"C:/Users/Zack/Desktop/pyout", "w") as f:
#     for tag in tags:
#         tagList.append(tag.contents[0])
#         tagfreq = tag.b.text.strip("()")
#         freq.append(tagfreq)
#     f.write(str(tagList))
#     f.write(str(tagfreq))
#     print(tagList)
#     print(freq)
