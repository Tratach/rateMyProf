import glob
import pandas as pd
#
# path = r"C:\Users\Zack\Desktop\csvs"
#
# all_files = glob.glob(path + "/*.csv")
# li = []
# for filename in all_files:
#     print(filename)
#     df = pd.read_csv(filename)
#     li.append(df)
#
# frame = pd.concat(li, axis=0, ignore_index=True)
#
# frame.to_csv("combined.csv", index=False)

csvPath = r"C:/Users/Zack/Desktop/tags.csv"
#csv = pd.read_csv(csvPath)
with open(csvPath, "r") as f:
    d = f.readlines()

    data = [word.split(',') for word in open(csvPath, 'r').readlines()]
    print(data)

