import java.util.ArrayList;

public class FullClass{
	
	private ArrayList<Professor>  professors;
	private String overallGPA;
	private String className;
	
	public FullClass(ArrayList<Professor> professors, String overallGPA, String name) {
		this.professors = professors;
		this.overallGPA = overallGPA;
		this.className = name;
	}
	
	public String getName() {
		return className;
	}
	
	public ArrayList<Professor>  getProfessor() {
		return professors;
	}
	
	public String getOverallGPA() {
		return overallGPA;
	}
	
}