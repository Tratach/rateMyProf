import javafx.application.Application;

//imported the two below for toggle
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main extends Application {

	Scene screen1, screen2, screen3;
	TextField idField;
	Button addClassBtn;
	Button resetBtn;
	Button deleteBtn;
	Label idFieldLabel;
	Label ratingDescLabel;
	Label ratingLabel;
	ListView<Class> classList;
	Button firstToSecond;
	Button thirdToSecond;
	Pane layout1;
	Pane layout2;
	Pane layout3;
	Student student;
	String classId;
	
	String q1Answer;
	String q2Answer;
	String q3Answer;
	String q4Answer;
	String q5Answer;
	ListView<Professor> profListView;
	
	List<Professor> profListG = new ArrayList<Professor>();

	DataParser dp = new DataParser();
	
	public static void main(String[] args) throws IOException {
		
		
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		dp.process();
		// class ID field
		idField = new TextField();
		idField.setLayoutX(200);
		idField.setLayoutY(100);
	
		// Add Class button
		addClassBtn = new Button("Add Class");
		addClassBtn.setLayoutX(400);
		addClassBtn.setLayoutY(100);
		addClassBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				stage.setScene(screen3);
				stage.setTitle("Page 3");
				classId = idField.getText();
				
				//System.out.println(classId);
				profListG = dp.getProfs(classId);
				
				System.out.println(dp.getProfs(classId).size());
				
			}
		});
	
		// Reset Button
		resetBtn = new Button("Reset");
		resetBtn.setLayoutX(325);
		resetBtn.setLayoutY(800);
		resetBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				stage.setScene(screen1);
				stage.setTitle("Page 1");
			}
		});
	
		// Delete Button
		deleteBtn = new Button("Delete");
		deleteBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (student.removeClass(classList.getSelectionModel().getSelectedItem().getName())) {
					classList.getItems().remove(classList.getSelectionModel().getSelectedIndex());
				}
				ratingLabel.setText("" + getAvgRating());
			}
		});
		deleteBtn.setLayoutX(325);
		deleteBtn.setLayoutY(600);
	
		// class id field label
		idFieldLabel = new Label("Enter class ID");
		idFieldLabel.setLayoutX(240);
		idFieldLabel.setLayoutY(125);
	
		// semester rating description label
		ratingDescLabel = new Label("Semester Rating");
		ratingDescLabel.setLayoutX(305);
		ratingDescLabel.setLayoutY(675);
	
		// rating rating label
		ratingLabel = new Label("--");
		ratingLabel.setLayoutX(340);
		ratingLabel.setLayoutY(725);
	
		// class list listview
		classList = new ListView<>();
		classList.setLayoutX(225);
		classList.setLayoutY(175);
	
		Label l1 = new Label("Q1");
		l1.setLayoutX(350);
		l1.setLayoutY(50);
		Label l2 = new Label("Q2");
		l2.setLayoutX(350);
		l2.setLayoutY(150);
		Label l3 = new Label("Q3");
		l3.setLayoutX(350);
		l3.setLayoutY(250);
		Label l4 = new Label("Q4");
		l4.setLayoutX(350);
		l4.setLayoutY(350);
		Label l5 = new Label("Q5");
		l5.setLayoutX(350);
		l5.setLayoutY(450);
	
		Label labelY1 = new Label("Yes");
		labelY1.setLayoutX(300);
		labelY1.setLayoutY(100);
		Label labelN1 = new Label("No");
		labelN1.setLayoutX(400);
		labelN1.setLayoutY(100);
		Label labelY2 = new Label("Yes");
		labelY2.setLayoutX(300);
		labelY2.setLayoutY(200);
		Label labelN2 = new Label("No");
		labelN2.setLayoutX(400);
		labelN2.setLayoutY(200);
		Label labelY3 = new Label("Yes");
		labelY3.setLayoutX(300);
		labelY3.setLayoutY(300);
		Label labelN3 = new Label("No");
		labelN3.setLayoutX(400);
		labelN3.setLayoutY(300);
		Label labelY4 = new Label("Yes");
		labelY4.setLayoutX(300);
		labelY4.setLayoutY(400);
		Label labelN4 = new Label("No");
		labelN4.setLayoutX(400);
		labelN4.setLayoutY(400);
		Label labelY5 = new Label("Yes");
		labelY5.setLayoutX(300);
		labelY5.setLayoutY(500);
		Label labelN5 = new Label("No");
		labelN5.setLayoutX(400);
		labelN5.setLayoutY(500);
		RadioButton y1 = new RadioButton();
		y1.setLayoutX(300);
		y1.setLayoutY(75);
		RadioButton y2 = new RadioButton();
		y2.setLayoutX(300);
		y2.setLayoutY(175);
		RadioButton y3 = new RadioButton();
		y3.setLayoutX(300);
		y3.setLayoutY(275);
		RadioButton y4 = new RadioButton();
		y4.setLayoutX(300);
		y4.setLayoutY(375);
		RadioButton y5 = new RadioButton();
		y5.setLayoutX(300);
		y5.setLayoutY(475);
		RadioButton n1 = new RadioButton();
		n1.setLayoutX(400);
		n1.setLayoutY(75);
		RadioButton n2 = new RadioButton();
		n2.setLayoutX(400);
		n2.setLayoutY(175);
		RadioButton n3 = new RadioButton();
		n3.setLayoutX(400);
		n3.setLayoutY(275);
		RadioButton n4 = new RadioButton();
		n4.setLayoutX(400);
		n4.setLayoutY(375);
		RadioButton n5 = new RadioButton();
		n5.setLayoutX(400);
		n5.setLayoutY(475);
	
		ToggleGroup q1 = new ToggleGroup();
		y1.setUserData("Yes");
		y1.setToggleGroup(q1);
		// y1.setSelected(true);
		n1.setUserData("No");
		n1.setToggleGroup(q1);
	
		ToggleGroup q2 = new ToggleGroup();
		y2.setUserData("Yes");
		y2.setToggleGroup(q2);
		// y2.setSelected(true);
		n2.setUserData("No");
		n2.setToggleGroup(q2);
	
		ToggleGroup q3 = new ToggleGroup();
		y3.setUserData("Yes");
		y3.setToggleGroup(q3);
		// y3.setSelected(true);
		n3.setUserData("No");
		n3.setToggleGroup(q3);
	
		ToggleGroup q4 = new ToggleGroup();
		y4.setUserData("Yes");
		y4.setToggleGroup(q4);
		// y4.setSelected(true);
		n4.setUserData("No");
		n4.setToggleGroup(q4);
	
		ToggleGroup q5 = new ToggleGroup();
		y5.setUserData("Yes");
		y5.setToggleGroup(q5);
		// y5.setSelected(true);
		n5.setUserData("No");
		n5.setToggleGroup(q5);
	
		q1.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
				if (q1.getSelectedToggle() != null) {
					if (q1.getSelectedToggle().getUserData().toString().equals("Yes"))
						q1Answer = "1";
					else
						q1Answer = "0";
					// Do something here with the userData of newly selected radioButton
				}
			}
		});
	
		q2.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
				if (q2.getSelectedToggle() != null) {
					if (q2.getSelectedToggle().getUserData().toString().equals("Yes"))
						q2Answer = "1";
					else
						q2Answer = "0";
					// Do something here with the userData of newly selected radioButton
				}
			}
		});
	
		q3.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
				if (q3.getSelectedToggle() != null) {
					if (q3.getSelectedToggle().getUserData().toString().equals("Yes"))
						q3Answer = "1";
					else
						q3Answer = "0";
					// Do something here with the userData of newly selected radioButton
				}
			}
		});
	
		q4.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
				if (q4.getSelectedToggle() != null) {
					if (q4.getSelectedToggle().getUserData().toString().equals("Yes"))
						q4Answer = "1";
					else
						q4Answer = "0";
					// Do something here with the userData of newly selected radioButton
				}
			}
		});
	
		q5.selectedToggleProperty().addListener(new ChangeListener<Toggle>() {
			public void changed(ObservableValue<? extends Toggle> ov, Toggle old_toggle, Toggle new_toggle) {
				if (q5.getSelectedToggle() != null) {
					if (q5.getSelectedToggle().getUserData().toString().equals("Yes"))
						q5Answer = "1";
					else
						q5Answer = "0";
					// Do something here with the userData of newly selected radioButton
				}
			}
		});
	
		// page 1 submit button
		firstToSecond = new Button("Submit");
		firstToSecond.setLayoutX(335);
		firstToSecond.setLayoutY(550);
		firstToSecond.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				List<String> prefList = new ArrayList<>();
				prefList.add(q1Answer);
				prefList.add(q2Answer);
				prefList.add(q3Answer);
				prefList.add(q4Answer);
				prefList.add(q5Answer);
				student = new Student(prefList);
				stage.setScene(screen2);
				stage.setTitle("Page 2");
			}
		});
	
		profListView = new ListView<Professor>();
		profListView.setLayoutX(225);
		profListView.setLayoutY(175);
		//Professor prof = new Professor("Andrea", "3141", "3.3", "5.0");
		//Professor prof1 = new Professor("motro", "5241", "1.1", "1.0");
		List<Professor> profList = new ArrayList<>();
		//profList.add(prof);
		//profList.add(prof1);
		
		//List<Professor> profListActual = dp.getProfs(classId);
		//System.out.println(profListG);
		
		for (Professor temp : profListG) {
			profListView.getItems().add(temp);
		}
	
		// page 3 submit button
		thirdToSecond = new Button("Submit");
		thirdToSecond.setLayoutX(330);
		thirdToSecond.setLayoutY(600);
		thirdToSecond.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				stage.setScene(screen2);
				stage.setTitle("Page 2");
				//profListView.getSelectionModel().getSelectedItem();
				//student.addClass(Class object goes here);
				Class newClassObj = new Class("3.4", classId, profListView.getSelectionModel().getSelectedItem());
				student.addClass(newClassObj);
				classList.getItems().add(newClassObj);
				ratingLabel.setText("" + getAvgRating());
			}
		});
	
		// Screen 1
		layout1 = new Pane();
		layout1.getChildren().add(firstToSecond);
		layout1.getChildren().add(l1);
		layout1.getChildren().add(l2);
		layout1.getChildren().add(l3);
		layout1.getChildren().add(l4);
		layout1.getChildren().add(l5);
		layout1.getChildren().add(y1);
		layout1.getChildren().add(n1);
		layout1.getChildren().add(labelY1);
		layout1.getChildren().add(labelN1);
		layout1.getChildren().add(y2);
		layout1.getChildren().add(n2);
		layout1.getChildren().add(labelY2);
		layout1.getChildren().add(labelN2);
		layout1.getChildren().add(y3);
		layout1.getChildren().add(n3);
		layout1.getChildren().add(labelY3);
		layout1.getChildren().add(labelN3);
		layout1.getChildren().add(y4);
		layout1.getChildren().add(n4);
		layout1.getChildren().add(labelY4);
		layout1.getChildren().add(labelN4);
		layout1.getChildren().add(y5);
		layout1.getChildren().add(n5);
		layout1.getChildren().add(labelY5);
		layout1.getChildren().add(labelN5);
		// Screen 2
		layout2 = new Pane();
		layout2.getChildren().add(idField);
		layout2.getChildren().add(addClassBtn);
		layout2.getChildren().add(resetBtn);
		layout2.getChildren().add(deleteBtn);
		layout2.getChildren().add(idFieldLabel);
		layout2.getChildren().add(ratingDescLabel);
		layout2.getChildren().add(ratingLabel);
		layout2.getChildren().add(classList);
	
		// Screen 3
		layout3 = new Pane();
		layout3.getChildren().add(thirdToSecond);
		layout3.getChildren().add(profListView);
	
		// create scenes
		screen1 = new Scene(layout1, 700, 900);
		screen2 = new Scene(layout2, 700, 900);
		screen3 = new Scene(layout3, 700, 900);
	
		// set scene
		stage.setTitle("Page 1");
		stage.setScene(screen1);
	
		// _______________________________________________________________________________________
	
		List<String> pref = new ArrayList<String>();
		List<Class> schedule = new ArrayList<Class>();
		List<Professor> professorList = new ArrayList<Professor>();
	
		// 1st screen should initialize the sudent object like this
		// pref.add("1");
		// pref.add("0");
		// pref.add("0");
		// pref.add("1");
		// pref.add("0");
		// student = new Student(pref);
	
		// 2nd screen needs to check Student.getSchedule() and populate any class items
		// in list view
		// delete function should check if Student.getSchedule.removeClass("className")
		// returns t/f, handle it
		// recheck Student.getSchedule and repopulate list
		// Add class button will call getClassOfferings(String classCode)
		// include some method to add number to rating
	
		Professor professor = new Professor("Andrea", "3141", "3.3", "5.0");
		Professor professor1 = new Professor("motro", "5241", "1.1", "1.0");
		professorList.add(professor);
		professorList.add(professor1);
		professor.tags.add("1");
		professor.tags.add("1");
		professor.tags.add("1");
		professor.tags.add("1");
		professor.tags.add("1");
		professor1.tags.add("0");
		professor1.tags.add("0");
		professor1.tags.add("0");
		professor1.tags.add("0");
		professor1.tags.add("0");
	
		Class newClass = new Class("3.4", "CS 310", professor);
		// student.addClass(newClass);
	
		// Screen 3 you get an array of professor objects, display and make them
		// selectable
		// Submit button should create a Class object with the Professor data and add it
		// to the Student schedule
	
		// List<Professor> profList = new ArrayList();
		// profList.add(professor);
		// profList.add(professor1);
	
		Class newClass1 = new Class("2.1", "CS 474", professor1);
	
		/*
		 * student.addClass(newClass1); for(int i=0; i<student.getSchedule().size();
		 * i++) { System.out.println(student.getSchedule().get(i).getName()); }
		 * 
		 * for(Class temp : student.getSchedule()) { classList.getItems().add(temp); }
		 */
	
		// _____________________________________________________________________________________
	
		stage.show();
	}

	public void createPreferences(String preference, List<String> pref) {
		pref.add(preference);
	}

	public void createFreq(String frequency, List<String> freq) {
		freq.add(frequency);
	}

	public float getAvgRating() {
		float labelNum = 0;
		float counter = 0;
		for (Class temp : student.getSchedule()) {
			labelNum += Float.parseFloat(temp.getOverallGPA());
			counter++;
		}
		return (labelNum / counter);
	}
}
