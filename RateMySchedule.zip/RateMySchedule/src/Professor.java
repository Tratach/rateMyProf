import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Professor {
	private String name;
	private String tid;
	private String gpa = "2.5";
	private String rating = "2.5";
	List<String> tags = new ArrayList<String>();
	
	public Professor(String profName, String ptid, String profGPA, String profRating, ArrayList<String> tags) {
		this.name = profName;
		this.tid = ptid;
		this.gpa = profGPA;
		this.rating = profRating;
		this.tags = tags;
		if(tags.size()==1) {
			tags = new ArrayList<String>(Arrays.asList("0","0","0","0","0"));
		}
	}
	
	public String getTags() {
		return tags.toString();
	}
	public void SetName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public String getTid() {
		return this.tid;
	}
	
	public String getGpa() {
		return this.gpa;
	}
	
	public String getRating() {
		return this.rating;
	}
	
	@Override
    public String toString() { 
        return getName(); 
    } 
}
