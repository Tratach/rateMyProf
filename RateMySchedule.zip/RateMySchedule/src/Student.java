import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Student {
	
	private List<String> preferences = new ArrayList<String>();
	private List<Class> schedule = new ArrayList<Class>();
	
	public Student(List<String> pref) {
		this.preferences = pref;
	}
	public void setSchedule() {
		this.schedule = null;
	}
	public void addClass(Class section) {
		schedule.add(section);
	}
	
	public boolean removeClass(String className) {
		for(int i=0; i<schedule.size(); i++) {
			if(schedule.get(i).getName() == className) {
					schedule.remove(i);
					return true;
			}
		}
		System.out.println("Class " + className + " not found");
		return false;
	}
	
	public void addPreference(String pref) {
		preferences.add(pref);
	}
	
	public void removePreference(String pref) {
		for(int i=0; i<preferences.size(); i++) {
			if(preferences.get(i) == pref) {
					preferences.remove(i);
					return;
			}
		}
		System.out.println("Class " + pref + " not found");
		
	}
	
	public List<Class> getSchedule(){
		return schedule;
	}
	
	public List<String> getPreferences(){
		return preferences;
	}
	
	public int getEuclidian(List<String> student, List<String> prof) {
		
		if(student.size() == 0) {
			student = new ArrayList<String>(Arrays.asList("0","0","0","0","0"));
			
		}
		if(prof.size() == 0) {
			prof = new ArrayList<String>(Arrays.asList("0","0","0","0","0"));
			
		}
		int score = 0;
		for(int i = 0; i<5; i++) {
			if(student.get(i).equals("1") && prof.get(i).equals("0")) {
				score -= 1;
			}
			if(student.get(i).equals("1") && prof.get(i).equals("1")) {
				score += 1;
			}
			if(student.get(i).equals("0") && prof.get(i).equals("1")) {
				score -= 1;
			}
			if(student.get(i).equals("0") && prof.get(i).equals("0")) {
				score -= 0;
			}
		}
		return score;
	}
	
	
//	public String getProfessorName(Class cls, String ClassName) {
//			return cls.getProfessor().getName();
//	}
	
}
