import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class DataParser {
	// skip class?
	public ArrayList<String> one = new ArrayList<String>(Arrays.asList("skipclass?youwontpass.", "bewareofpopquizzes", "lectureheavy")); 
	// many or few assignments
	public ArrayList<String> two = new ArrayList<String>(Arrays.asList("lotsofhomework", "gradedbyfewthings", "somanypapers", "getreadytoread")); 
	// interact with prof
	public ArrayList<String> three = new ArrayList<String>(Arrays.asList("accessibleoutsideclass", "cleargradingcriteria", "amazinglectures" )); 
	// test heavy
	public ArrayList<String> four = new ArrayList<String>(Arrays.asList("testheavy")); 
	// work well with others ?
	public ArrayList<String> five = new ArrayList<String>(Arrays.asList("participationmatters", "groupprojects")); 
	
	
	public static HashMap<String, HashMap<String,String[]>> classes = new HashMap<String, HashMap<String,String[]>>();
	public static HashMap<String, String[]> rateMyProf = new HashMap<String, String[]>();
	public static HashMap<String, ArrayList<String>> rateMyProfIds = new HashMap<String, ArrayList<String>>();
	String classId = "";
	
	public ArrayList<String> getProfPref(String profName){
		ArrayList<String> ret = new ArrayList<String>();
		String get = rateMyProf.get(profName)[2];
		ArrayList<String> tags = rateMyProfIds.get(get);
		String[] addTo = {"0","0","0","0","0"};
		System.out.println(tags);
		for(String i : tags) {
			i = i.replaceAll(" ", "");
			i = i.toLowerCase();

			if(one.contains(i)) {
				addTo[0] = "1";
			
			}
			if(two.contains(i)) {
				addTo[1] = "1";
			
			}
			if(three.contains(i)) {
				addTo[2] = "1";
			
			}
			if(four.contains(i)) {
				addTo[3] = "1";
			
			}
			if(five.contains(i)) {
				addTo[4] = "1";
			
			}
		}
		ret = new ArrayList<String>(Arrays.asList(addTo));
		
		return ret;
	}
	
	public void rmpIds() throws FileNotFoundException {
		File t = new File("/Users/arunkrishnavajjala/eclipse-workspace/RateMySchedule/src/tags2.csv");
		Scanner s = new Scanner(t);
		int c = 0;
		while(s.hasNext()) {
			String spl = s.nextLine();
			spl = spl.replaceAll(" ", "");
			String[] splt = spl.split(",");
			ArrayList<String>  add = new ArrayList<String>();
			if(splt[1].equals("0")){
				add.add("No_Tags");
			}else {
				for(int i = 1; i<splt.length; i++) {
					add.add(splt[i]);
				}
			}
			rateMyProfIds.put(splt[0], add);
		}
	}
	
	
	public String getGpa(String[] splt) {
		double totalGpa = 0;
		double gpa = 0;
	    double totalStudents = 0;
	    for(int i = 0; i<splt.length; i++) {
	    	Double mult =  Double.parseDouble(splt[i]);
	    	totalStudents += mult;
	    }
		totalGpa += 4.00 * Double.parseDouble(splt[0]);
		totalGpa += 4.00 * Double.parseDouble(splt[1]);
		totalGpa += 3.67 * Double.parseDouble(splt[2]);
		totalGpa += 3.33 * Double.parseDouble(splt[3]);
		totalGpa += 3.00 * Double.parseDouble(splt[4]);
		totalGpa += 2.67 * Double.parseDouble(splt[5]);
		totalGpa += 2.33 * Double.parseDouble(splt[6]);
		totalGpa += 2.00 * Double.parseDouble(splt[7]);
		totalGpa += 1.67 * Double.parseDouble(splt[8]);
		totalGpa += 1.00 * Double.parseDouble(splt[9]);
		totalGpa += 0.00 * Double.parseDouble(splt[10]);
	    gpa = totalGpa/totalStudents;
	    String retGpa = gpa + "";
		return retGpa;
	}
	
	public double classGPA(ArrayList<Professor> profs) {
		double totalGpa = 0;
		double profcount = 0;
		for(Professor i : profs) {
			totalGpa += Double.parseDouble(i.getGpa());
			profcount += 1;
		}
		totalGpa /= profcount;
		return totalGpa;
	}
	
	public ArrayList<Professor> getProfs(String id) {
		ArrayList<Professor> profs = new ArrayList<Professor>();
		if(classes.containsKey(id)) {
			id = id.toUpperCase();
			HashMap<String,String[]> vals = classes.get(id);
			String[] skrt = classes.get(id).get(classes.get(id).keySet().toArray());
			
			for(int i = 0; i< classes.get(id).size(); i++) {
				//System.out.print(classes.get(id).get(classes.get(id).keySet().toArray()[i])[0] + "    ");
				//System.out.println(classes.get(id).get(classes.get(id).keySet().toArray()[i])[1]);
				
				String prof = classes.get(id).get(classes.get(id).keySet().toArray()[i])[0];
				String gpa = classes.get(id).get(classes.get(id).keySet().toArray()[i])[1];
				prof = prof.replaceAll("[\\p{C}]", "");
				
				if(rateMyProf.get(prof) == null) {
					//System.out.println("No Rate Info");
					ArrayList<String> gg = new ArrayList<String>();
					gg.add("0");
					gg.add("0");
					gg.add("0");
					gg.add("0");
					gg.add("0");
					ArrayList<String> tags = new ArrayList<String>();
					Professor p = new Professor(prof, "NOTID", gpa, "0", tags);
					profs.add(p);
					
				}else {
					System.out.println(rateMyProf.get(prof)[3]);
					// rating#, classRating, tid,  rating
					ArrayList<String> tags = this.getProfPref(prof);
					//Professor p = new Professor(prof, rateMyProf.get(prof)[2], gpa, rateMyProfIds.get(rateMyProf.get(prof)[2]), rateMyProf.get(prof)[3]);
					Professor p = new Professor(prof, rateMyProf.get(prof)[2], gpa, rateMyProf.get(prof)[3], tags);
					profs.add(p);
				}
			}
		}
		
		String sGpa = classGPA(profs) + "";
		return profs;
	}
	
	public void importData() throws IOException {
		int counter;
		File text;
		Scanner scnr;
		String[] spring = {"2012", "2013","2014","2015","2016"};
		String[] fall = {"2011", "2012","2013","2014","2015"};
		for(int s = 0; s<spring.length; s++) {
			String yr = spring[s];
			text = new File("/Users/arunkrishnavajjala/eclipse-workspace/RateMySchedule/src/spring"+yr+".txt");
			scnr = new Scanner(text);
			counter = 0;
			while(scnr.hasNextLine()){
				String line = scnr.nextLine();
				if(counter > 0) {
					String[] splt = line.split("\t");
					String prof = splt[1];
					String classId = splt[0];
					prof = prof.replace('"', Character.MIN_VALUE);
					//[2:13]
					String[] gpacalc = new String[12];
					int ind = 2;
					for(int i = 0; i<gpacalc.length; i++) {
						gpacalc[i] = splt[ind + i];
					}
					String calcGpa = getGpa(gpacalc);
					String[] profGpa = {prof, calcGpa};
					if(classes.containsKey(classId)) {
						if(classes.get(classId).keySet().contains(prof)) {
							double gpa1 = Double.parseDouble(classes.get(classId).get(prof)[1]);
							double gpa2 = Double.parseDouble(profGpa[1]);
							double newGpa = (gpa1 + gpa2) / 2;
							String[] nprofGpa = profGpa;
							nprofGpa[1] = newGpa + "";
							classes.get(classId).put(prof, nprofGpa);
							
						}else {
							classes.get(classId).put(prof, profGpa);
						}
					}else {
						HashMap<String, String[]> h = new HashMap<String, String[]>();
						h.put(prof,profGpa);
						classes.put(classId, h);
					}
				}
				counter += 1;
			}
		}
		for(int s = 0; s<fall.length; s++) {
			String yr = fall[s];
			text = new File("/Users/arunkrishnavajjala/eclipse-workspace/RateMySchedule/src/fall"+yr+".txt");
			scnr = new Scanner(text);
			counter = 0;
			while(scnr.hasNextLine()){
				String line = scnr.nextLine();
				if(counter > 0) {
					String[] splt = line.split("\t");
					String prof = splt[1];
					String classId = splt[0];
					prof = prof.replace('"', Character.MIN_VALUE);
					//[2:13]
					String[] gpacalc = new String[12];
					int ind = 2;
					for(int i = 0; i<gpacalc.length; i++) {
						gpacalc[i] = splt[ind + i];
					}
					String calcGpa = getGpa(gpacalc);
					String[] profGpa = {prof, calcGpa};
					if(classes.containsKey(classId)) {
						if(classes.get(classId).keySet().contains(prof)) {
							double gpa1 = Double.parseDouble(classes.get(classId).get(prof)[1]);
							double gpa2 = Double.parseDouble(profGpa[1]);
							double newGpa = (gpa1 + gpa2) / 2;
							String[] nprofGpa = profGpa;
							nprofGpa[1] = newGpa + "";
							classes.get(classId).put(prof, nprofGpa);
							
						}else {
							classes.get(classId).put(prof, profGpa);
						}
					}else {
						HashMap<String, String[]> h = new HashMap<String, String[]>();
						h.put(prof,profGpa);
						classes.put(classId, h);
					}
				}
				counter += 1;
			}
		}
	}
	
	public void rmpProcess() throws FileNotFoundException {
		for(int i = 0; i <265; i++) {
			File f = new File("/Users/arunkrishnavajjala/eclipse-workspace/RateMySchedule/src/csvs 2/completeProfList"+ i +".csv");
			Scanner sc = new Scanner(f);
			int c = 0;
			int gap = 0;
			
			while(sc.hasNext()) {
				String line = sc.nextLine();
				if(gap % 2 == 0) {
					if(gap != 0) {
						String[] splt = line.split(",");
						String profName = splt[5] + ", " + splt[3];
						//              rating#, classRating, tid,  rating
						String[] info = {splt[7], splt[8], splt[6], splt[11]};
						rateMyProf.put(profName, info);
					}
				}
				gap += 1;
			}
		}
	}
	
	public void process() throws IOException {
		importData();
		rmpProcess();
		rmpIds();
	}
	
//	public static void main(String[] args) throws IOException {
//		importData();
//		rmpProcess();
//		String cs = "";
//		Scanner sc = new Scanner(System.in);
//		rmpIds();
//		while(!cs.equals("n")) {
//			System.out.print("Class Name: ");
//			String s = sc. nextLine();
//			if(s.equals("n")) {
//				break;
//			}
//			getProfs(s);
//		}
//		
//	}
}




















