
public class Analyzer {
		
		int[] studentPref = {1,0,1,1,0};
		int[] profPref = {0,0,1,1,1};
		double avgGPA = 3.1;
		int range = 2;
		double rmpRating = 4.1;
		double profGPA = 2.8;
		
		public double profGPA(double profGPA) {
			return profGPA*0.3;
		}
		
		public double adjustRMP(double rating) {
			rating /= 5;
			rating -= 0.5;
			rating *= 2;
			return rating*.3;
		}
		
		public float calcPrefWeight(int[] stu, int[] prof) {
			float prefWeight=0;
			
			for(int i=0; i<5;i++) {
				if(stu[i] == 1 && prof[i] ==1) {
					prefWeight+=0.08;
				}
				else if(stu[i] == 0 && prof[i] == 0) {
					prefWeight+=0;
				}
				else if(stu[i] == 1 && prof[i] == 0) {
					prefWeight-=0.05;
				}
				else if(stu[i] == 0 && prof[i] == 1) {
					prefWeight-=0.05;
				}
			}
			
			return prefWeight;
		}
			
}
