import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class Class{
	
	private Professor professor;
	private String overallGPA;
	private String className;
	private String projected = "0";
	
	public Class(String overallGPA, String name, Professor professor) {
		this.overallGPA = overallGPA;
		this.className = name;
		this.professor = professor;
	}
	public String getProjected() {
		return projected;
	}
	
	public void setProjected(String projected) {
		this.projected = projected; ;
	}
	
	public String getName() {
		return className;
	}
	
	public Professor getProfessor() {
		return professor;
	}
	
	public String getOverallGPA() {
		return overallGPA;
	}
	
	@Override
    public String toString() { 
		DecimalFormat df = new DecimalFormat("0.00");
		String overallGPA = df.format(Double.parseDouble(getOverallGPA()));
		String projected = df.format(Double.parseDouble(getProjected()));
		
        return "Class: " + getName() + "\nProfessor: " + getProfessor() + "\nClass GPA: " + overallGPA+ "\nProjected GPA: " + projected; 
    } 
}














