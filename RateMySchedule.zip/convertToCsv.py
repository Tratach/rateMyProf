import json

import csv

with open(r"C:/Users/Zack/Desktop/FixedGMUProf.json", "r") as n:
    counter = 0
    while n:

        json_data = n.readline()

        json_parsed = json.loads(json_data)
        employ_data = open(r'C:/Users/Zack/Desktop/csvs/completeProfList' + str(counter) + '.csv', 'w')

        csvwriter = csv.writer(employ_data)

        count = 0
        emp_data = json_parsed
        for emp in emp_data:

              header = emp.keys()
              if count == 0:
                     csvwriter.writerow(header)
                     count += 1

              csvwriter.writerow(emp.values())
        print(counter)
        counter+=1
        employ_data.close()