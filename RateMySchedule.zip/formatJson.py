

with open(r"C:/Users/Zack/Desktop/completeproflist.txt", 'r') as f:
   list = f.readlines()
   with open (r"C:/Users/Zack/Desktop/FixedGMUProf.json", "w") as n:

       for i in list:
           swap = i.replace("'", '"')
           n.write(swap)
           print (swap)

