import requests
import json
import time
import pymongo

db = pymongo.MongoClient().local.ratemyprofs

counter = 0

for i in range(1, 266):

    query = "http://www.ratemyprofessors.com/filter/professor/?department=&institution=George+Mason+University&page=" + str(
        i) + "&filter=teacherlastname_sort_s+asc&query=*%3A*&queryoption=TEACHER&queryBy=schoolId&sid=352"

    try:
        page = requests.get(query)
        jsonpage = json.loads(page.content)
        professorlist = jsonpage['professors']

        if len(professorlist) > 0:
            print(professorlist)
            for prof in professorlist:
                if db.find_one({"tid": int(prof['tid'])}) is None:
                    db.insert(prof)
        with open (r"C:/Users/Zack/Desktop/results.txt", "w") as f:
            print("page " + str(i) + " " + '\xF0\x9F\x98\x8F')
            f.write(professorlist)
    except:
        pass

    time.sleep(1)